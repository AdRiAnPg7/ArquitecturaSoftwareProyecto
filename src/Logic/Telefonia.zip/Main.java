package Logic;


import java.time.LocalTime;



public class Main {
	
	

	public static void main(String [ ] args) {
		/* int numeroOrigen = 77556644;
		int numeroDestino = 66116611;
		TarifaStrategy tarifaHorario = new TarifaHorarios();
		PlanPrePago planPrePago = new PlanPrePago();
		Telefono telefonoOrigen = new Telefono(numeroOrigen,null);
		Telefono telefonoDestino = new Telefono(numeroDestino,null);
		LocalTime horaInicioLlamada = LocalTime.parse("00:01:00");
		LocalTime tiempoDuracionLlamada = LocalTime.parse("00:01:00");
		Llamada llamada = new Llamada() ;
		CDR CDR= new CDR (telefonoOrigen,telefonoDestino,horaInicioLlamada,tiempoDuracionLlamada);
		planPrePago.aniadirTarifa(tarifaHorario);
		telefonoOrigen.aniadirPlan(planPrePago);
		llamada.aniadirCDR(CDR);
		System.out.println("aaaaaaaaaaaaaa"+llamada.calcularCosto());*/
		
		RegistroCDRs CDRs = new RegistroCDRs();
		CDRs.cargarCDRs();
		CDRs.mostrar();
		
		
		/*LocalTime test = null;
		test = LocalTime.parse("00:01");
		System.out.print(test.getHour());
		System.out.print(test.getMinute());
		System.out.print(test.getSecond());*/
		
		
	}

}
