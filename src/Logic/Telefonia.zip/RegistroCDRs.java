package Logic;

import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.ArrayList;

public class RegistroCDRs {
	
	LocalTime HoraInicioLlamada = null;
	LocalTime DuracionLlamada = null;
	Telefono telefonoOrigen = new Telefono(0,null);
	Telefono telefonoDestino = new Telefono(0,null);
	ArrayList <CDR> CDRs  = new ArrayList<CDR>();
	
	public void cargarCDRs() {
		
		Path filePath = Paths.get("C:\\Users\\Adrian\\eclipse-workspace\\TelefoniaViva\\CDRs.csv");

		try {
			BufferedReader br = Files.newBufferedReader(filePath);
			String linea ="";
			while((linea = br.readLine())!=null) {
				String[] datosDeLinea = linea.split(",");
				telefonoOrigen.aniadirNumero(Integer.parseInt(datosDeLinea[0]));
				System.out.print( "aaaaaaaa"+ telefonoOrigen.obtenerNumero()); 
				telefonoDestino.aniadirNumero(Integer.parseInt(datosDeLinea[1]));
				System.out.print( "nnnnnnnn"+ telefonoDestino.obtenerNumero());
				HoraInicioLlamada = LocalTime.parse(datosDeLinea[2]);
				DuracionLlamada = LocalTime.parse(datosDeLinea[3]);
				
				CDR temporal = new CDR(telefonoOrigen,telefonoDestino,HoraInicioLlamada,DuracionLlamada);
				CDRs.add(temporal);
			}
			
		}catch(Exception e){
			System.err.println("No se encontro archivo");
		}
	}
	
	public void mostrar() {
		for (CDR CDR: CDRs) {
		    System.out.print(CDR.obtenerNumeroDelTelefonoOrigen());
		    System.out.print( "  ");  
		    System.out.print(CDR.obtenerNumeroDelTelefonoDestino());
		    System.out.print( "  "); 
		    System.out.print(CDR.obtenerHoraInicioLlamada());
		    System.out.print( "  "); 
		    System.out.print(CDR.obtenerDuracionLlamada());
		    System.out.print( " ---- "); 
		}
	}
}
