package Logic;

public interface TarifaStrategy {
	
	public float calcularTarifa(CDR CDR);

}
